Custom environments using Mujoco for AI Gym.

To install run pip install -e /path/to/package ("Example pip install -e ~/Desktop/my_envs")

To change the max number of steps per episode change in the my_envs/my_envs/__init__.py file